from faster_whisper import WhisperModel
from moviepy.editor import VideoFileClip
import os
import pandas as pd
from datetime import datetime

def process_video(video_path, output_folder):
    model = WhisperModel("base", compute_type="int8")
    segments, _ = model.transcribe(video_path)

    video = VideoFileClip(video_path)
    video_duration = video.duration
    os.makedirs(output_folder, exist_ok=True)

    log = {
        "clip_id": [],
        "file_name": [],
        "start": [],
        "end": [],
        "duration_sec": [],
        "recognized_text": [],
    }

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    MIN_DURATION = 15
    i = 0
    segment_list = list(segments)
    clip_count = 0

    while i < len(segment_list) and clip_count < 3:
        start = segment_list[i].start
        end = segment_list[i].end
        text = segment_list[i].text.strip()

        for j in range(i+1, min(i+3, len(segment_list))):
            end = segment_list[j].end
            text += " " + segment_list[j].text.strip()

        start = max(0, start - 2)
        end = min(video_duration, end + 2)
        duration = round(end - start)

        if duration < MIN_DURATION:
            i += 3
            continue

        file_name = f"clip_{clip_count+1}_{timestamp}.mp4"
        path = os.path.join(output_folder, file_name)
        video.subclip(start, end).write_videofile(path)

        log["clip_id"].append(f"clip_{clip_count+1}")
        log["file_name"].append(file_name)
        log["start"].append(start)
        log["end"].append(end)
        log["duration_sec"].append(duration)
        log["recognized_text"].append(text)

        i += 3
        clip_count += 1

    df = pd.DataFrame(log)
    df["tags"] = "ai, speech"
    df["category"] = "AutoClips"
    df["created_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    df.to_csv("clips_database.csv", index=False)

    return df.to_dict(orient="records"), "clips_database.csv"
