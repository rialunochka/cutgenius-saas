from flask import Flask, request, render_template, send_file
import os
from clipper import process_video

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'clips'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        video = request.files['video']
        path = os.path.join(UPLOAD_FOLDER, video.filename)
        video.save(path)

        clips, csv_path = process_video(path, RESULT_FOLDER)

        return render_template("result.html", clips=clips, csv_path=csv_path)

    return render_template("index.html")

@app.route('/download/<filename>')
def download(filename):
    return send_file(os.path.join(RESULT_FOLDER, filename), as_attachment=True)

@app.route('/download/csv')
def download_csv():
    return send_file("clips_database.csv", as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
